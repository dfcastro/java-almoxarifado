package model;

public class ItemRelatorio{
	
		private int itemRelatorio;

		/**
		 * @return the itemRelatorio
		 */
		public int getItemRelatorio() {
			return itemRelatorio;
		}

		/**
		 * @param itemRelatorio the itemRelatorio to set
		 */
		public void setItemRelatorio(int itemRelatorio) {
			this.itemRelatorio = itemRelatorio;
		}
		

}
