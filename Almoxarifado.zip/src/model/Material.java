package model;

public class Material {

	private long idMaterial;	
	private String codigoMaterial;
	private String nomeMaterial;
	private String unidadeMaterial;
	private String tipoMaterial;
	/**
	 * @return the idMaterial
	 */
	public long getIdMaterial() {
		return idMaterial;
	}
	/**
	 * @param idMaterial the idMaterial to set
	 */
	public void setIdMaterial(long idMaterial) {
		this.idMaterial = idMaterial;
	}
	/**
	 * @return the codigoMaterial
	 */
	public String getCodigoMaterial() {
		return codigoMaterial;
	}
	/**
	 * @param codigoMaterial the codigoMaterial to set
	 */
	public void setCodigoMaterial(String codigoMaterial) {
		this.codigoMaterial = codigoMaterial;
	}
	/**
	 * @return the unidadeMaterial
	 */
	public String getUnidadeMaterial() {
		return unidadeMaterial;
	}
	/**
	 * @param unidadeMaterial the unidadeMaterial to set
	 */
	public void setUnidadeMaterial(String unidadeMaterial) {
		this.unidadeMaterial = unidadeMaterial;
	}
	/**
	 * @return the nomeMaterial
	 */
	public String getNomeMaterial() {
		return nomeMaterial;
	}
	/**
	 * @param nomeMaterial the nomeMaterial to set
	 */
	public void setNomeMaterial(String nomeMaterial) {
		this.nomeMaterial = nomeMaterial;
	}
	/**
	 * @return the tipoMaterial
	 */
	public String getTipoMaterial() {
		return tipoMaterial;
	}
	/**
	 * @param tipoMaterial the tipoMaterial to set
	 */
	public void setTipoMaterial(String tipoMaterial) {
		this.tipoMaterial = tipoMaterial;
	}
}
