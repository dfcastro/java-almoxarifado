package model;

public class Relatorio {
	private long idRelatorio;
	private String dataRelatorio;
	/**
	 * @return the idRelatorio
	 */
	public long getIdRelatorio() {
		return idRelatorio;
	}
	/**
	 * @param idRelatorio the idRelatorio to set
	 */
	public void setIdRelatorio(long idRelatorio) {
		this.idRelatorio = idRelatorio;
	}
	/**
	 * @return the dataRelatorio
	 */
	public String getDataRelatorio() {
		return dataRelatorio;
	}
	/**
	 * @param dataRelatorio the dataRelatorio to set
	 */
	public void setDataRelatorio(String dataRelatorio) {
		this.dataRelatorio = dataRelatorio;
	}
	
	
	

}
